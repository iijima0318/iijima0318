<html>
<div  style="text-align:center">
<?php
//DB接続設定
$dsn='mysql:dbname=tb221374db;host=localhost';
$user='tb-221374';
$password='QeE8aSwmeM';
$pdo=new PDO($dsn,$user,$password,array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_WARNING));

//テーブルの作成
$sql="CREATE TABLE IF NOT EXISTS mission5"
."("
."id INT AUTO_INCREMENT PRIMARY KEY,"
."name char(32),"
."comment TEXT,"
."pass TEXT,"
."date DATETIME"
.");";
$stmt=$pdo->query($sql);

//変数の定義
$p_name=$_POST["name"];
$p_comment=$_POST["comment"];
$delete=$_POST["dele"];
$edit=$_POST["edit"];
$p_date=date("Y/m/d H:i:s");
$passcode=$_POST["passcode"];
$n_passcode=$_POST["n_passcode"];
$n_name=$_POST["n_name"];
$n_comment=$_POST["n_comment"];


//投稿機能
if(isset($p_name,$p_comment,$passcode)){
    if(!empty($p_name&&$p_comment)&&!empty($passcode)){
        $sql=$pdo->prepare("INSERT INTO mission5(name,comment,pass,date)VALUES(:name,:comment,:pass,:date)");
        $sql->bindParam(':name',$name,PDO::PARAM_STR);
        $sql->bindParam(':comment',$comment,PDO::PARAM_STR);
        $sql->bindParam(':pass',$pass,PDO::PARAM_STR);
        $sql->bindParam(':date',$date,PDO::PARAM_STR);
        $name=$p_name;
        $comment=$p_comment;
        $pass=$passcode;
        $date=$p_date;
        $sql->execute();
    }else{
        echo "情報が不足しています。";
    }
}




//削除機能
if(isset($delete,$passcode)){
    if(!empty($delete&&$passcode)){
        $sql='SELECT*FROM mission5';
        $stmt=$pdo->query($sql);
        $results=$stmt->fetchAll();
        foreach($results as $row){
            if($row['id']==$delete){
                if($row['pass']==$passcode){
                    $id=$delete;
                    $sql='delete from mission5 where id=:id';
                    $stmt=$pdo->prepare($sql);
                    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
                    $stmt->execute();
                }else{
                    echo "パスワードが違います。";
                }
            }
        }
    }
}

//編集機能
if(isset($edit,$passcode)){
    if(!empty($edit&&$passcode)){
        $sql='SELECT*FROM mission5';
        $stmt=$pdo->query($sql);
        $results=$stmt->fetchAll();
        foreach($results as $row){
            if($row['id']==$edit){
                if($row['pass']==$passcode){
                    $sql='UPDATE mission5 SET name=:name, comment=:comment,pass=:pass,date=:date WHERE id=:id';
                    $stmt=$pdo->prepare($sql);
                    $stmt->bindParam(':name', $n_name, PDO::PARAM_STR);
                    $stmt->bindParam(':comment', $n_comment, PDO::PARAM_STR);
                    $stmt->bindParam(':pass',$n_passcode, PDO::PARAM_STR);
                    $stmt->bindParam(':date',$p_date, PDO::PARAM_STR);
                    $stmt->bindParam(':id', $edit, PDO::PARAM_STR);
                    $stmt->execute();
                }else{
                    echo "パスワードが違います。";
                }
            }
        }
    }
}

echo "<br>";

//データの表示
$sql='SELECT*FROM mission5';
$stmt=$pdo->query($sql);
$results=$stmt->fetchAll();
foreach($results as $row){
    echo $row['id'].',';//カラム名はそろえる
    echo $row['name'].',';
    echo $row['comment'].',';
    echo $row['date'].',';
    echo "<hr>";
}
?>
</div>
</html>

<!DOCTYPE html>
<html lang="ja">
    <head>
        <meta charset="utf=8">
        <title>mission5</title>
    </head>
    <body>
       <div  style="text-align:center">
        <form action=""method="post">
            <input type="hidden"name="post_num">
            <input type="text"name="name"placeholder="Your name"><br>
            <input type="text"name="comment"placeholder="Please comment"><br>
            <input type="text"name="passcode"placeholder="passcode"><br>
            <input type="submit"name="submit"value="送る">
        </form>
        <br>
        <form action=""method="post">
            <input type="text"name="dele"placeholder="削除番号を入力"><br>
            <input type="text"name="passcode"placeholder="passcode"><br>
            <input type="submit"name="submit"value="削除実行">
        </form>
        <br>
        <form action=""method="post">
            <input type="text"name="edit"placeholder="編集番号を入力"><br>
            <input type="text"name="n_name"placeholder="Your name"><br>
            <input type="text"name="n_comment"placeholder="Please comment"><br>
            <input type="text"name="passcode"placeholder="Before passcode"><br>
            <input type="text"name="n_passcode"placeholder="After passcode"><br>
            <input type="submit"name="submit"value="編集">
        </form>
       </div>
    </body>
</html>